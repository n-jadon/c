package com.capgemini.ProductCartManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCartManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagementApplication.class, args);
	}

}
