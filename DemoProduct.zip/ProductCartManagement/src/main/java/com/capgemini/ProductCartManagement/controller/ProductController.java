package com.capgemini.ProductCartManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.ProductCartManagement.Service.ProductServiceImpl;
import com.capgemini.ProductCartManagement.bean.Product;

@RestController
@RequestMapping("products")
public class ProductController {
	@Autowired
	ProductServiceImpl service;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Product> view(){
		return service.view();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public Product create(@RequestBody Product product)
	{
		return service.create(product);
	}
	
	@RequestMapping(method=RequestMethod.GET,value="{id}")
	public Product find(@PathVariable(value="id") String id) {
		return service.find(id);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="{id}")
	public Product update(@RequestBody Product product,@PathVariable(value="id") long id) {
		return service.update(product);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="{id}")
	public Product delete(@PathVariable(value="id") String id) {
		return service.delete(id);
	}
}
