package com.capgemini.ProductCartManagement.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import com.capgemini.ProductCartManagement.bean.Product;

@Repository
public class ProductRepoImpl implements IProductRepo{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Product create(Product product) {
		try {
			entityManager.persist(product);
		}
		catch (RuntimeException e) {
			throw e;
		}
		entityManager.close();
		entityManager.flush();
		return product;
	}

	@Override
	public List<Product> view() {
			Query query = entityManager.createQuery("select prod from Product prod");
			List<Product> ls=(List<Product>)query.getResultList();
			entityManager.close();
			entityManager.flush();
			return ls;
	}

	@Override
	public Product find(String id) {
		Product product= entityManager.find(Product.class, id);
		if(product==null)
			return null;
		product.setId(id);
		return product;
	}

	@Override
	public Product update(Product product) {
		entityManager.merge(product);
		entityManager.flush();
		return product;
	}

	@Override
	public Product delete(String id) {
		Product product= entityManager.find(Product.class, id);
		entityManager.remove(product);
		entityManager.flush();
		return product;
	}

}
