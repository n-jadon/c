package com.capgemini.ProductCartManagement.DAO;

import java.util.List;

import com.capgemini.ProductCartManagement.bean.Product;

public interface IProductRepo {
	public Product create(Product product);
	public List<Product> view();
	public Product find(String id);
	public Product update(Product product);
	public Product delete(String id);
}
